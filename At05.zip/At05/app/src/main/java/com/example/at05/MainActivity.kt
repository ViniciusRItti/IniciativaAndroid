package com.example.at05

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.at05.R

class MainActivity : AppCompatActivity() {

    private lateinit var editTextHeight: EditText
    private lateinit var editTextWeight: EditText
    private lateinit var buttonCalculate: Button
    private lateinit var textViewResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextHeight = findViewById(R.id.editTextHeight)
        editTextWeight = findViewById(R.id.editTextWeight)
        buttonCalculate = findViewById(R.id.buttonCalculate)
        textViewResult = findViewById(R.id.textViewResult)

        buttonCalculate.setOnClickListener { calculateBMI() }
    }

    private fun calculateBMI() {
        val heightText = editTextHeight.text.toString()
        val weightText = editTextWeight.text.toString()

        if (heightText.isNotEmpty() && weightText.isNotEmpty()) {
            val height = heightText.toDouble()
            val weight = weightText.toDouble()
            val bmi = weight / (height * height)

            val category = when {
                bmi < 18.5 -> "Abaixo do peso"
                bmi in 18.5..24.9 -> "Peso normal"
                bmi in 25.0..29.9 -> "Sobrepeso"
                else -> "Obesidade"
            }

            textViewResult.text = "IMC: %.2f\nCategoria: $category".format(bmi)
        } else {
            textViewResult.text = "Por favor, preencha todos os campos."
        }
    }
}
