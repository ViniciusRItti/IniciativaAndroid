package com.example.at03

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.at03.R

class MainActivity : AppCompatActivity() {

    private lateinit var editTextPassword: EditText
    private lateinit var buttonVerify: Button
    private lateinit var textViewResult: TextView
    private val correctPassword = "1234"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextPassword = findViewById(R.id.editTextPassword)
        buttonVerify = findViewById(R.id.buttonVerify)
        textViewResult = findViewById(R.id.textViewResult)

        buttonVerify.setOnClickListener { verifyPassword() }
    }

    private fun verifyPassword() {
        val inputPassword = editTextPassword.text.toString()
        textViewResult.text = if (inputPassword == correctPassword) {
            "Senha correta"
        } else {
            "Senha incorreta"
        }
    }
}
