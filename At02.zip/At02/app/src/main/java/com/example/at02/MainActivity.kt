package com.example.at02


import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.at02.R


class MainActivity : AppCompatActivity() {

    private lateinit var editTextNumber1: EditText
    private lateinit var editTextNumber2: EditText
    private lateinit var textViewResult: TextView
    private lateinit var buttonSum: Button
    private lateinit var buttonSubtract: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextNumber1 = findViewById(R.id.editTextNumber1)
        editTextNumber2 = findViewById(R.id.editTextNumber2)
        textViewResult = findViewById(R.id.textViewResult)
        buttonSum = findViewById(R.id.buttonSum)
        buttonSubtract = findViewById(R.id.buttonSubtract)

        buttonSum.setOnClickListener { performOperation(true) }
        buttonSubtract.setOnClickListener { performOperation(false) }
    }

    private fun performOperation(isSum: Boolean) {
        val number1Text = editTextNumber1.text.toString()
        val number2Text = editTextNumber2.text.toString()

        if (number1Text.isNotEmpty() && number2Text.isNotEmpty()) {
            val number1 = number1Text.toDouble()
            val number2 = number2Text.toDouble()
            val result = if (isSum) {
                number1 + number2
            } else {
                number1 - number2
            }
            textViewResult.text = "Resultado: $result"
        } else {
            textViewResult.text = "Por favor, insira os dois números."
        }
    }
}
