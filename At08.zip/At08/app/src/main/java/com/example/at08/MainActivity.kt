package com.example.at08

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.at08.R

class MainActivity : AppCompatActivity() {

    private lateinit var editTextTemperature: EditText
    private lateinit var radioGroup: RadioGroup
    private lateinit var buttonConvert: Button
    private lateinit var textViewResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextTemperature = findViewById(R.id.editTextTemperature)
        radioGroup = findViewById(R.id.radioGroup)
        buttonConvert = findViewById(R.id.buttonConvert)
        textViewResult = findViewById(R.id.textViewResult)

        buttonConvert.setOnClickListener { convertTemperature() }
    }

    private fun convertTemperature() {
        val temperatureText = editTextTemperature.text.toString()

        if (temperatureText.isNotEmpty()) {
            val temperature = temperatureText.toDouble()
            val selectedConversion = radioGroup.checkedRadioButtonId
            val result: Double

            result = when (selectedConversion) {
                R.id.radioCtoF -> (temperature * 9 / 5) + 32 // Celsius para Fahrenheit
                R.id.radioFtoC -> (temperature - 32) * 5 / 9 // Fahrenheit para Celsius
                else -> return
            }

            textViewResult.text = "Resultado: %.2f".format(result)
        } else {
            textViewResult.text = "Por favor, insira uma temperatura."
        }
    }
}
