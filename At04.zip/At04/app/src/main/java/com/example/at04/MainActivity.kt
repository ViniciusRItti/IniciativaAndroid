package com.example.at04

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.at04.R

class MainActivity : AppCompatActivity() {

    private lateinit var editTextValue: EditText
    private lateinit var editTextConversionRate: EditText
    private lateinit var buttonConvert: Button
    private lateinit var textViewResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextValue = findViewById(R.id.editTextValue)
        editTextConversionRate = findViewById(R.id.editTextConversionRate)
        buttonConvert = findViewById(R.id.buttonConvert)
        textViewResult = findViewById(R.id.textViewResult)

        buttonConvert.setOnClickListener { convertCurrency() }
    }

    private fun convertCurrency() {
        val valueText = editTextValue.text.toString()
        val conversionRateText = editTextConversionRate.text.toString()

        if (valueText.isNotEmpty() && conversionRateText.isNotEmpty()) {
            val value = valueText.toDouble()
            val conversionRate = conversionRateText.toDouble()
            val convertedValue = value * conversionRate
            textViewResult.text = "Valor convertido: $convertedValue"
        } else {
            textViewResult.text = "Por favor, preencha todos os campos."
        }
    }
}
