package com.example.adivinhaonumero

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.at07.R
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var editTextGuess: EditText
    private lateinit var buttonCheck: Button
    private lateinit var textViewFeedback: TextView
    private var randomNumber = Random.nextInt(1, 101) // Número aleatório entre 1 e 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextGuess = findViewById(R.id.editTextGuess)
        buttonCheck = findViewById(R.id.buttonCheck)
        textViewFeedback = findViewById(R.id.textViewFeedback)

        buttonCheck.setOnClickListener { checkGuess() }
    }

    private fun checkGuess() {
        val guessText = editTextGuess.text.toString()

        if (guessText.isNotEmpty()) {
            val guess = guessText.toInt()

            when {
                guess < randomNumber -> textViewFeedback.text = "Seu palpite é muito baixo."
                guess > randomNumber -> textViewFeedback.text = "Seu palpite é muito alto."
                else -> textViewFeedback.text = "Parabéns! Você acertou."
            }
        } else {
            textViewFeedback.text = "Por favor, insira um número."
        }
    }
}
